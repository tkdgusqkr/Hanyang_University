package 박상현_2022024348;

public interface Account {
	void deposit(double amount);
	void withdraw(double amount);
	double getBalance();
}

package Cafe;

public interface Observer {
	public void update(int index, String name);
}
